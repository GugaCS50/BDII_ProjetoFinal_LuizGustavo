from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_bootstrap import Bootstrap5
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Email  
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = '8BYkEfBA6O6donzWlSihBXox7C0sKR6b'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///devs.db'  
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
Bootstrap5(app)

db = SQLAlchemy(app)

class Developer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    password = db.Column(db.String(100), nullable=False)
    cel = db.Column(db.String(20), nullable=False)
    habilidades = db.Column(db.Text, nullable=False)

class DevSkipCompany(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dev_id = db.Column(db.Integer, db.ForeignKey('developer.id'), nullable=False)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)

class CompanySkipDev(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    dev_id = db.Column(db.Integer, db.ForeignKey('developer.id'), nullable=False)

class DevForm(FlaskForm):
    name = StringField('Nome', validators=[DataRequired()])
    email = StringField('E-mail', validators=[DataRequired()])
    password = StringField('Password', validators=[DataRequired()])
    cel = StringField('Celular', validators=[DataRequired()])
    habilidades = TextAreaField('Habilidades', validators=[DataRequired()])
    submit= SubmitField('Cadastrar')

class DevLoginForm(FlaskForm):
    email = StringField('E-mail', validators=[DataRequired(), Email()])
    password = StringField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    password = db.Column(db.String(100), nullable=False)  
    telefone = db.Column(db.String(20), nullable=False)
    descricao = db.Column(db.Text, nullable=False)

class CompanyForm(FlaskForm):
    name = StringField('Nome do Time', validators=[DataRequired()])
    email = StringField('E-mail', validators=[DataRequired()])
    password = StringField('Password', validators=[DataRequired()])
    telefone = StringField('Telefone', validators=[DataRequired()])
    descricao = TextAreaField('Descrição do Time', validators=[DataRequired()])
    submit = SubmitField('Cadastrar')

class CompanyLoginForm(FlaskForm):
    email = StringField('E-mail', validators=[DataRequired(), Email()])
    password = StringField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class CompanyEditForm(FlaskForm):
    name = StringField('Nome do Time', validators=[DataRequired()])
    descricao = TextAreaField('Descrição do Time', validators=[DataRequired()])
    submit = SubmitField('Salvar Alterações')

class DevEditForm(FlaskForm):
    name = StringField('Nome', validators=[DataRequired()])
    habilidades = TextAreaField('Posição', validators=[DataRequired()])
    submit = SubmitField('Salvar Alterações')

class Match(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dev_id = db.Column(db.Integer, db.ForeignKey('developer.id'), nullable=False)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    match_date = db.Column(db.DateTime, default=db.func.current_timestamp())

def check_if_match_exists(dev_id, company_id):
    print(f"Checking match for Developer ID: {dev_id}, Company ID: {company_id}")
    match = Match.query.filter_by(dev_id=dev_id, company_id=company_id).first()
    print(f"Match found: {match}")
    return match is not None


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/dev/login", methods=["GET", "POST"])
def dev_login():
    form = DevLoginForm()

    if request.method == "POST":  
        if form.validate_on_submit():
            email = form.email.data
            password = form.password.data
            
            developer = Developer.query.filter_by(email=email).first()

            if developer and developer.password == password:
                
                session['developer_id'] = developer.id

                return redirect(url_for('dev_profile'))
            else:
                flash('Credenciais inválidas. Tente novamente.', 'danger')

        else:
            print("Erros de validação:", form.errors)

    return render_template("dev_login.html", form=form)


@app.route("/dev/profile")
def dev_profile():
    if 'developer_id' not in session:
        flash('Por favor, faça login primeiro.', 'warning')
        return redirect(url_for('dev_login'))

    developer_id = session['developer_id']

    developer = Developer.query.get(developer_id)

    if developer is None:
        flash('jogador não encontrado.', 'danger')
        return redirect(url_for('dev_login'))

    developer_info = {
        "name": developer.name,
        "email": developer.email,
        "cel": developer.cel,
        "habilidades": developer.habilidades
    }

    return render_template("dev_profile.html", developer=developer_info)

@app.route("/dev/edit_profile", methods=["GET", "POST"])
def dev_edit_profile():
    if 'developer_id' not in session:
        flash('Por favor, faça login primeiro.', 'warning')
        return redirect(url_for('dev_login'))

    dev_id = session['developer_id']
    developer = Developer.query.get_or_404(dev_id)
    form = DevEditForm(obj=developer)

    if form.validate_on_submit():
        developer.name = form.name.data
        developer.habilidades = form.habilidades.data
        db.session.commit()
        flash('Perfil do jogador atualizado com sucesso!', 'success')
        return redirect(url_for('dev_profile'))

    return render_template("dev_edit_profile.html", form=form)


@app.route("/company/edit_profile", methods=["GET", "POST"])
def company_edit_profile():
    if 'company_id' not in session:
        flash('Por favor, faça login primeiro.', 'warning')
        return redirect(url_for('company_login'))

    company_id = session['company_id']
    company = Company.query.get_or_404(company_id)
    form = CompanyEditForm(obj=company)

    if form.validate_on_submit():
        company.name = form.name.data
        company.descricao = form.descricao.data
        db.session.commit()
        flash('Perfil do time atualizado com sucesso!', 'success')
        return redirect(url_for('company_profile'))

    return render_template("company_edit_profile.html", form=form)

@app.route("/dev/register", methods=["GET", "POST"])
def dev_register():
    form = DevForm()

    if form.validate_on_submit():
        existing_dev_email = Developer.query.filter_by(email=form.email.data).first()
        existing_dev_pass = Developer.query.filter_by(password=form.password.data).first()
        
        if existing_dev_email and existing_dev_pass:
            flash('Esse email já está registrado. Por favor, use outro.', 'danger')
            return redirect(url_for('dev_register'))

        try:
            new_dev = Developer(
                name=form.name.data,
                email=form.email.data,
                password=form.password.data,
                cel=form.cel.data,
                habilidades=form.habilidades.data
            )
            db.session.add(new_dev)
            db.session.commit()
            flash('jogador registrado com sucesso!', 'success')
            return redirect(url_for('home'))
        
        except Exception as e:
            db.session.rollback()
            flash(f'Ocorreu um erro ao registrar o jogador: {str(e)}', 'danger')

    return render_template("dev_register.html", form=form)

@app.route("/company/register", methods=["GET", "POST"])
def company_register():
    form = CompanyForm()
    if form.validate_on_submit():
        existing_company = Company.query.filter_by(email=form.email.data).first()
        if existing_company:
            flash('Esse e-mail já está registrado. Por favor, use outro.', 'danger')
            return redirect(url_for('company_register'))

        new_company = Company(
            name=form.name.data,
            email=form.email.data,
            password=form.password.data, 
            telefone=form.telefone.data,
            descricao=form.descricao.data
        )
        db.session.add(new_company)
        db.session.commit()  
        flash('Time registrado com sucesso!', 'success')
        return redirect(url_for('home'))
    return render_template("company_register.html", form=form)

@app.route("/company/login", methods=["GET", "POST"])
def company_login():
    form = CompanyLoginForm()
    if request.method == "POST":
        if form.validate_on_submit():
            email = form.email.data
            password = form.password.data

            company = Company.query.filter_by(email=email).first()
            if company and company.password == password:  
                session['company_id'] = company.id

                flash(f'Bem-vindo, {company.name}!', 'success')
                return redirect(url_for('company_profile'))
            else:
                print("Erros de validação:", form.errors)
                flash('E-mail ou senha inválidos. Tente novamente.', 'danger')
                return redirect(url_for('company_login'))
    return render_template("company_login.html", form=form)

@app.route("/company/profile")
def company_profile():
    if 'company_id' not in session:
        flash('Por favor, faça login primeiro.', 'warning')
        return redirect(url_for('company_login'))

    company_id = session['company_id']

    company = Company.query.get(company_id)

    if company is None:
        flash('Time não encontrado.', 'danger')
        return redirect(url_for('company_login'))

    company_info = {
        "name": company.name,
        "email": company.email,
        "telefone": company.telefone,
        "descricao": company.descricao
    }

    return render_template("company_profile.html", company=company_info)

@app.route("/dev/logout")
def dev_logout():
    session.pop('developer_id', None)  
    flash('Você foi desconectado.', 'success')
    return redirect(url_for('dev_login'))

@app.route("/company/logout")
def company_logout():
    session.pop('company_id', None)  
    flash('Você foi desconectado.', 'success')
    return redirect(url_for('company_login'))


def get_evaluated_company_ids(dev_id):
    evaluated_matches = Match.query.filter_by(dev_id=dev_id).all()
    evaluated_company_ids = [match.company_id for match in evaluated_matches]
    return evaluated_company_ids

def get_next_empresa_for_dev(dev_id):
    evaluated_company_ids = get_evaluated_company_ids(dev_id)  

    next_company = Company.query.filter(Company.id.notin_(evaluated_company_ids)).first()

    return next_company

def get_next_dev_for_company(company_id):
    skipped_dev_ids = get_skipped_dev_ids(company_id)
    
    matched_dev_ids = Match.query.filter_by(company_id=company_id).with_entities(Match.dev_id).all()
    matched_dev_ids = [dev_id[0] for dev_id in matched_dev_ids]  

    return Developer.query.filter(
        ~Developer.id.in_(skipped_dev_ids), 
        ~Developer.id.in_(matched_dev_ids)
    ).first()



def get_skipped_company_ids(dev_id):
    skipped = DevSkipCompany.query.filter_by(dev_id=dev_id).all()
    return [s.company_id for s in skipped]

def get_skipped_dev_ids(company_id):
    skipped = CompanySkipDev.query.filter_by(company_id=company_id).all()
    return [s.dev_id for s in skipped]

@app.route("/dev/skip/<int:company_id>", methods=["GET"])
def dev_skip(company_id):
    if 'developer_id' not in session:
        flash('Por favor, faça login primeiro.', 'warning')
        return redirect(url_for('dev_login'))

    dev_id = session['developer_id']

    skip = DevSkipCompany(dev_id=dev_id, company_id=company_id)
    db.session.add(skip)
    db.session.commit()

    next_empresa = get_next_empresa_for_dev(dev_id)

    if next_empresa:
        return render_template("dev_match.html", empresa=next_empresa)
    else:
        flash('Nenhum novo time disponível no momento.', 'info')
        return redirect(url_for('dev_profile'))
    
@app.route("/company/skip/<int:dev_id>", methods=["GET"])
def company_skip(dev_id):
    if 'company_id' not in session:
        flash('Por favor, faça login primeiro.', 'warning')
        return redirect(url_for('company_login'))

    company_id = session['company_id']

    skip = CompanySkipDev(company_id=company_id, dev_id=dev_id)
    db.session.add(skip)
    db.session.commit()

    next_dev = get_next_dev_for_company(company_id)

    if next_dev:
        return render_template("company_match.html", dev=next_dev)
    else:
        flash('Nenhum novo jogador disponível no momento.', 'info')
        return redirect(url_for('company_profile'))
    
@app.route("/company/match", methods=["GET", "POST"])
def company_match():
    if 'company_id' not in session:
        flash('Por favor, faça login primeiro.', 'warning')
        return redirect(url_for('company_login'))

    company_id = session['company_id']

    next_dev = get_next_dev_for_company(company_id)
    
    if request.method == "POST":
        print(f"Next Developer: {next_dev}")
        if next_dev:  
            if 'skip' in request.form:  
                print(f"Skipped Developer: {next_dev.name}")
                
                next_dev = get_next_dev_for_company(company_id)
                return render_template("company_match.html", dev=next_dev)
                
            elif 'match' in request.form:  
                print(f"Request Form: {request.form}")  
                
                if not check_if_match_exists(next_dev.id, company_id):  
                    new_match = Match(dev_id=next_dev.id, company_id=company_id)
                    db.session.add(new_match)
                    db.session.commit()
                    flash(f'Match com o jogador {next_dev.name} realizado com sucesso!', 'success')
                    print(f"Match created for Developer ID: {next_dev.id}, Company ID: {company_id}")  
                else:
                    flash(f'Você já deu match com o jogador {next_dev.name}.', 'info')
                
                next_dev = get_next_dev_for_company(company_id)
                print(f"Next Developer after match: {next_dev}")

                if next_dev:
                    return render_template("company_match.html", dev=next_dev)
                else:
                    flash('Nenhum novo jogador disponível no momento.', 'info')
                    return redirect(url_for('company_profile'))  

    return render_template("company_match.html", dev=next_dev)



@app.route("/dev/match", methods=["GET", "POST"])
def dev_match():
    print("Aqui 1")
    if 'developer_id' not in session:
        print("Aqui 2")
        flash('Por favor, faça login primeiro.', 'warning')
        return redirect(url_for('dev_login'))

    dev_id = session['developer_id']

    next_company = get_next_empresa_for_dev(dev_id)

    if not next_company:
        print("Aqui 3")
        flash('Nenhum novo time disponível ou houve um erro na busca.', 'warning')
        return redirect(url_for('dev_profile'))

    if request.method == "POST":
        print("Aqui 4")
        if next_company:  
            print("Aqui 5")
            if 'skip' in request.form:
                return dev_skip(next_company.id)
            elif 'match' in request.form:
                print("Aqui 6")
                if not check_if_match_exists(dev_id, next_company.id):
                    print("Aqui 7")
                    new_match = Match(dev_id=dev_id, company_id=next_company.id)
                    db.session.add(new_match)
                    db.session.commit()
                    flash(f'Match com o time {next_company.name} realizado com sucesso!', 'success')
                else:
                    flash(f'Você já deu match com o time {next_company.name}.', 'info')
                next_company = get_next_empresa_for_dev(dev_id)

    return render_template("dev_match.html", company=next_company)



with app.app_context():
    db.create_all()

if __name__ == '__main__':

    app.run(debug=True, port=5000)